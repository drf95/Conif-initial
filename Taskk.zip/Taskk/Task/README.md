# CCWSN_RL
This is an implementation of a Deep Reinforcement Learning based caching strategy for Content Centric Wireless Sensor Networks (CCWSN_RL).

- You are provided with an incomplete code : ./code/CCWSN.py

- In order to complete the code, you'll need to do four (4) tasks as mentioned in the file : ./Tasks.txt

- After completing the tasks, you may test the code using the provided emulation benchmark that uses : Docker + Tmux 
  (the provided benchmark uses 6 Docker containers as presented in the file : ./config_files/nodes.txt)

- You may choose to test the code directly on a group of Raspberry Pis.

- After successfully completing the code, you are asked to experiment with it in a large scale Raspberry Pi network (as many as provided). 


### FYI ###

./config_files/nodes.txt : contains nodes identified with their coordinates [x,y])

./config_files/config_ccwsn.txt : contains the broadcast address of all the nodes (must be changed if using a raspberry network).

./config_files/data.txt : contains the content (name;data) of each mentioned node (identified with its coordinates [x,y])

./config_files/interest.txt : contains interests (name;delay) of each mentioned node

./mytmux.sh : a bash script that automates the launch of all nodes with their corresponding data and interests 

